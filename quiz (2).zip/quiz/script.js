const quizData = [
  { q: "The first page of a website is called?", options: ["Design", "Home page", "First page", "Main page"], answer: 1 },
  { q: "How many heading tags are supported by HTML?", options: ["3", "4", "5", "6"], answer: 3 },
  { q: "Which is the largest heading tag?", options: ["H1", "H3", "H4", "H6"], answer: 0 },
  { q: "......................... connects web pages.", options: ["Connector", "Link", "Hyperlink", "None of the above"], answer: 2 },
  { q: "Which of the following protocol is used for e-mail services?", options: ["SMAP", "SMTP", "SMIP", "SMOP"], answer: 1 },
  { q: "................... is known as father of World Wide Web.", options: ["Robert Cailliau", "Tim Thompson", "Charles Darwin", "Tim Berners-Lee"], answer: 3 },
  { q: "What does an HTML tag do?", options: [
      "Specifies formatting and layout instructions",
      "Hides programming instructions",
      "Determines site structure",
      "Connects your website to OS"
    ], answer: 0 },
  { q: "Output of XML document can be viewed in a?", options: ["Word Processor", "Web browser", "Notepad", "None of the above"], answer: 1 },
  { q: "Choose the correct HTML tag to make the text bold.", options: ["<B>", "<BOLD>", "<STRONG>", "Both A & C"], answer: 3 },
  { q: "Which of the following are commonly found on web pages?", options: ["Internet", "Hyperlinks", "Intranet", "All of the above"], answer: 3 },
  { q: "What is an ISP?", options: ["Internet System Protocol", "Internal System Program", "Internet Service Provider", "None of the above"], answer: 2 },
  { q: "What is the language of the Web?", options: ["Basic", "C++", "MS Visual Basic", "HTML"], answer: 3 },
  { q: "Which of the following are attributes of Font tag?", options: ["Face", "Size", "Color", "All of above"], answer: 3 },
  { q: "HTML tags are surrounded by ___ brackets.", options: ["Angle", "Square", "Round", "Curly"], answer: 0 },
  { q: "HTML was first proposed in year ___.", options: ["1980", "1990", "1995", "2000"], answer: 1 },
  { q: "Which of the following is not an example of browser?", options: ["Netscape Navigator", "Microsoft Bing", "Mozilla Firefox", "Opera"], answer: 1 },
  { q: "The software that can read and render HTML documents is:", options: ["Server", "Compiler", "Interpreter", "Browser"], answer: 3 },
  { q: "HTML document can contain:", options: ["Attributes", "Tags", "Plain text", "All of these"], answer: 3 },
  { q: "HTML language is a set of markup ___", options: ["Attributes", "Tags", "Sets", "Groups"], answer: 1 },
  { q: "HTML is considered as ___ language", options: ["Programming Language", "OOP Language", "High Level Language", "Markup Language"], answer: 3 },
  { q: "Correct syntax to change font face:", options: [
      '<font = "font name">',
      '<font name = "font name">…</font>',
      '<font face = "font name">…</font>',
      'Font Face cannot change'
    ], answer: 2 },
  { q: "Correct syntax to align H1 tag to right:", options: [
      '<h1 align = "right">…</h1>',
      '<h1 alignment = "right">',
      '<h1 tag align = "right">',
      'H1 cannot align right'
    ], answer: 0 },
  { q: "Correct HTML tag to left-align cell content.", options: [
      "<tdleft>", "<td leftalign>", 'valign="left"', '<td align="left">'
    ], answer: 3 },
  { q: "Tags related to Table in HTML:", options: [
      "<table> <row> <column>",
      "<table> <tr> <td>",
      "<table> <head> <body>",
      "<table> <header> <footer>"
    ], answer: 1 },
  { q: "Set a picture as background:", options: [
      '<body background="bgimage.gif">',
      '<body background image="bgimage.gif">',
      '<background="bgimage.gif">',
      '<background image="bgimage.gif">'
    ], answer: 0 },
  { q: "FTP stands for:", options: [
      "File Transaction Protocol", "File Transmission Protocol",
      "File Translation Protocol", "File Transfer Protocol"
    ], answer: 3 },
  { q: "Use of iframe in HTML:", options: [
      "Display web page within a web page",
      "Display web page with animation",
      "Display web page without browser",
      "All of the above"
    ], answer: 0 },

  // ✅ Additional 45 questions
  { q: "HTML stands for?", options: ["Hyper Text Markup Language", "High Text Machine Language", "Hyperlinks and Text Markup Language", "None of the above"], answer: 0 },
  { q: "Which tag is used for inserting a line break?", options: ["<br>", "<break>", "<lb>", "<newline>"], answer: 0 },
  { q: "Choose the correct HTML tag for a new paragraph:", options: ["<p>", "<br>", "<para>", "<text>"], answer: 0 },
  { q: "Which tag is used to create an ordered list?", options: ["<ol>", "<ul>", "<li>", "<list>"], answer: 0 },
  { q: "Which tag is used to create a checkbox?", options: ["<check>", "<input type='checkbox'>", "<checkbox>", "<cb>"], answer: 1 },
  { q: "HTML comment syntax is:", options: ["<!-- comment -->", "// comment", "/* comment */", "# comment"], answer: 0 },
  { q: "Choose the correct HTML tag to make text italic.", options: ["<italic>", "<i>", "<it>", "<em>"], answer: 1 },
  { q: "Which tag is used to define an internal style sheet?", options: ["<style>", "<script>", "<css>", "<link>"], answer: 0 },
  { q: "Choose the correct HTML element for the largest heading:", options: ["<heading>", "<h6>", "<h1>", "<head>"], answer: 2 },
  { q: "Which of the following is correct to create a hyperlink?", options: [
      '<a href="url">link</a>', '<link="url">', '<href="url">link</href>', '<a url="link">'
    ], answer: 0 },
  { q: "Which HTML tag is used to display an image?", options: ["<img>", "<image>", "<pic>", "<src>"], answer: 0 },
  { q: "Choose the correct HTML attribute to open a link in new tab.", options: ["target='_blank'", "window='new'", "open='new'", "tab='new'"], answer: 0 },
  { q: "Which attribute is used to specify alternate text for an image?", options: ["title", "alt", "description", "caption"], answer: 1 },
  { q: "Which tag is used for creating a dropdown?", options: ["<select>", "<input type='dropdown'>", "<dropdown>", "<list>"], answer: 0 },
  { q: "Which tag is used for inserting JavaScript?", options: ["<script>", "<js>", "<javascript>", "<code>"], answer: 0 },
  { q: "Which tag is used for inserting CSS externally?", options: ["<style>", "<link>", "<css>", "<stylesheet>"], answer: 1 },
  { q: "Which tag creates a text input field?", options: ["<textbox>", "<input type='text'>", "<text>", "<field>"], answer: 1 },
  { q: "Which HTML attribute specifies the destination of a hyperlink?", options: ["src", "link", "href", "url"], answer: 2 },
  { q: "Which tag is used for table rows?", options: ["<row>", "<tr>", "<td>", "<th>"], answer: 1 },
  { q: "Which tag defines a table header cell?", options: ["<header>", "<td>", "<th>", "<head>"], answer: 2 },
  { q: "Choose correct tag for an unordered list:", options: ["<ol>", "<ul>", "<list>", "<li>"], answer: 1 },
  { q: "Choose correct tag for list item:", options: ["<item>", "<li>", "<list>", "<ul>"], answer: 1 },
  { q: "Which attribute is used to provide tooltip text?", options: ["title", "tooltip", "alt", "info"], answer: 0 },
  { q: "Which tag is used to group block-elements?", options: ["<span>", "<group>", "<div>", "<block>"], answer: 2 },
  { q: "Which tag is used to group inline-elements?", options: ["<div>", "<group>", "<span>", "<inline>"], answer: 2 },
  { q: "Choose correct HTML element for inserting a video.", options: ["<media>", "<movie>", "<video>", "<mp4>"], answer: 2 },
  { q: "Which attribute is used for specifying video controls?", options: ["controls", "play", "show", "buttons"], answer: 0 },
  { q: "Which HTML5 element is used for navigation links?", options: ["<navigate>", "<nav>", "<menu>", "<header>"], answer: 1 },
  { q: "Which HTML5 element represents a footer?", options: ["<bottom>", "<footer>", "<foot>", "<end>"], answer: 1 },
  { q: "Which HTML5 element represents an article?", options: ["<post>", "<article>", "<section>", "<content>"], answer: 1 },
  { q: "Which HTML5 element represents a section of content?", options: ["<part>", "<div>", "<section>", "<content>"], answer: 2 },
  { q: "Which input type is used for email validation?", options: ["text", "email", "mail", "input-email"], answer: 1 },
  { q: "Which input type is used for selecting a date?", options: ["calendar", "datetime", "date", "time"], answer: 2 },
  { q: "Which HTML attribute is used to specify required fields?", options: ["required", "must", "validate", "needed"], answer: 0 },
  { q: "Which input type creates a password field?", options: ["<input type='password'>", "<password>", "<secret>", "<hidden>"], answer: 0 },
  { q: "Which tag is used to embed an audio file?", options: ["<sound>", "<audio>", "<music>", "<mp3>"], answer: 1 },
  { q: "Which HTML attribute is used to autoplay media?", options: ["autoplay", "play", "auto", "start"], answer: 0 },
  { q: "Which tag is used for adding metadata?", options: ["<meta>", "<data>", "<head>", "<info>"], answer: 0 },
  { q: "Which attribute specifies character encoding?", options: ["charset", "encoding", "lang", "type"], answer: 0 },
  { q: "Which tag is used for main content?", options: ["<main>", "<body>", "<article>", "<section>"], answer: 0 },
  { q: "Which tag defines emphasized text?", options: ["<i>", "<italic>", "<em>", "<strong>"], answer: 2 },
  { q: "Which tag is used to highlight text?", options: ["<highlight>", "<mark>", "<yellow>", "<span>"], answer: 1 },
  { q: "Which HTML attribute disables an input field?", options: ["disabled", "readonly", "hidden", "disable"], answer: 0 }
];

let currentQuestion = 0;
let score = 0;

const quizQuestion = document.getElementById("quizQuestion");
const quizOptions = document.getElementById("quizOptions");
const nextBtn = document.getElementById("nextBtn");
const quizResult = document.getElementById("quizResult");

function showSection(section) {
  document.querySelectorAll(".section").forEach(s => s.classList.add("hidden"));
  document.getElementById(section).classList.remove("hidden");
  if (section === "quiz") {
    currentQuestion = 0;
    score = 0;
    quizResult.innerHTML = "";
    showQuestion();
  }
}

function showQuestion() {
  const q = quizData[currentQuestion];
  quizQuestion.innerHTML = `<h3>Q${currentQuestion + 1}: ${q.q}</h3>`;
  quizOptions.innerHTML = "";
  q.options.forEach((opt, idx) => {
    const btn = document.createElement("button");
    btn.innerText = opt;
    btn.classList.add("option-btn");
    btn.onclick = () => checkAnswer(idx);
    quizOptions.appendChild(btn);
  });
  nextBtn.style.display = "none";
}

function checkAnswer(selected) {
  const q = quizData[currentQuestion];
  const buttons = quizOptions.querySelectorAll("button");
  buttons.forEach((btn, idx) => {
    btn.disabled = true;
    if (idx === q.answer) btn.classList.add("correct");
    if (idx === selected && idx !== q.answer) btn.classList.add("wrong");
  });
  if (selected === q.answer) score++;
  nextBtn.style.display = "block";
  nextBtn.innerText = currentQuestion === quizData.length - 1 ? "Submit Quiz" : "Next Question";
}

function nextQuestion() {
  currentQuestion++;
  if (currentQuestion < quizData.length) {
    showQuestion();
  } else {
    showResult();
  }
}

function showResult() {
  quizQuestion.innerHTML = "";
  quizOptions.innerHTML = "";
  nextBtn.style.display = "none";

  let percentage = Math.round((score / quizData.length) * 100);
  let grade = percentage >= 80 ? "Excellent ✅" : percentage >= 50 ? "Good 🙂" : "Needs Improvement ❌";

  quizResult.innerHTML = `
    <h3>Quiz Completed!</h3>
    <p>Your Score: <b>${score}</b> / ${quizData.length}</p>
    <p>Grade: <b>${grade}</b> (${percentage}%)</p>
    <button onclick="showSection('quiz')">Restart Quiz</button>
    <button onclick="showSection('home')">Back to Menu</button>
  `;
}

function runCode() {
  const userCode = document.getElementById("codeInput").value;
  document.getElementById("codeOutput").srcdoc = userCode;
}
